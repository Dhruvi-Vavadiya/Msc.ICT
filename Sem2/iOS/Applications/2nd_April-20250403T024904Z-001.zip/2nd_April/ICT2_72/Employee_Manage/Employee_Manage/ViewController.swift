//
//  ViewController.swift
//  Employee_Manage
//
//  Created by Ictbatch1 on 11/03/25.
//

import UIKit
import CoreData

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    var list : [NSManagedObject] = []
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Emp", for: indexPath)
                
                let employee = list[indexPath.row]
                
                // Configure the cell with more data from Core Data
                let name = employee.value(forKey: "empname") as? String ?? "No Name"
                let empid = employee.value(forKey: "empid") as? Int ?? 0
                let designation = employee.value(forKey: "des") as? String ?? "No Designation"
                
                let date = employee.value(forKey: "date")as? Date
               
        cell.textLabel?.text = "ID: \(empid) - \(name) - \(designation) - \(String(describing: date))"
                
                return cell
    }
    

    
    @IBOutlet weak var txt_des: UITextField!
    @IBOutlet weak var txt_ename: UITextField!
    @IBOutlet weak var txt_eid: UITextField!
    
    @IBOutlet weak var tableview: UITableView!
    @IBOutlet weak var date_picker: UIDatePicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let  dirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        print(dirPath[0])
        tableview.register(UITableViewCell.self, forCellReuseIdentifier: "Emp")
        btnFetch()
    }

    @IBAction func btn_del(_ sender: Any) {
        
        let appD2=UIApplication.shared.delegate as! AppDelegate

            //memery to secondary storege
        let mangeObjectCont2 = appD2.persistentContainer.viewContext
        
        let fre=NSFetchRequest<NSFetchRequestResult>(entityName: "Emp")
        
        //filtering
        fre.predicate=NSPredicate(format: "empid=%@", txt_eid!)
        
        do{
            let results = try mangeObjectCont2.fetch(fre)
            let obj = results[0] as! NSManagedObject
            mangeObjectCont2.delete(obj)
            do{
                try mangeObjectCont2.save()
                print("Record deleted....")
            }catch{
                
            }
        }catch{
            
        }
    }
    
    @IBAction func btn_add(_ sender: Any) {
        let appD=UIApplication.shared.delegate as! AppDelegate
        let mangedObject = appD.persistentContainer.viewContext
        
        let emp=NSEntityDescription.entity(forEntityName: "Emp", in: mangedObject)!
        
        let data = NSManagedObject(entity: emp, insertInto: mangedObject)
        
        data.setValue(Int16(txt_eid.text!), forKey: "empid")
        data.setValue(txt_ename.text!, forKey: "empname")
        data.setValue(txt_des.text!, forKey: "des")
        data.setValue(date_picker.date, forKey: "date")
        
        do{
            try mangedObject.save()
            print("Record inserttedd...")
        }catch{
            
        }
    }
    
    
    @IBAction func btn_read(_ sender: Any) {
        let appD1=UIApplication.shared.delegate as! AppDelegate

            //memery to secondary storege
        let mangeObjectCont1 = appD1.persistentContainer.viewContext
        
        //NSFe(entityname:)
        let fr=NSFetchRequest<NSManagedObject>(entityName: "Emp")
        
        do{
            let result=try mangeObjectCont1.fetch(fr)
            
            for data in result
            {
                print(data.value(forKey: "empid"))
                print(data.value(forKey: "empname")!)
                print(data.value(forKey: "des")!)
                print(data.value(forKey: "date")!)
            }
        }catch{
            
        }
        
    }
    @IBAction func btnFetch(){
                let appDelegate = UIApplication.shared.delegate as? AppDelegate
                let managedContext = appDelegate!.persistentContainer.viewContext
                
                let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Emp")
                
                do {
                    list = try managedContext.fetch(fetchRequest)
                    // Reload the table view to reflect the fetched data
                    //tableView.reloadData()
                } catch let error as NSError {
                    print("Could not fetch. \(error), \(error.userInfo)")
                }
    }
    
}

